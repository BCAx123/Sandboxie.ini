<?php
    require_once "conexao.php";    

    $erro= false;
    if(count($_POST) > 0) {
        $nome = $_POST['nome'];
        $email = $_POST['email'];
        $telefone = $_POST['telefone'];
        $nascimento = $_POST['nascimento'];
        
        if (empty($nome)) {
            $erro = "Preencha o nome";
        }
        if(empty($email)) {
            $erro = "Preencha o e-mail";
        }
        if(empty($nascimento)) {
            $erro ="Preencha a data de nascimento!";
        
        }

        // Converte a data de dd/mm/aaaa para aaaa-mm-dd
        $nascimento = date('Y-m-d', strtotime(str_replace('/', '-', $nascimento)));
        
        if($erro) {
            echo "<p><b>ERRO: $erro</b></p>";
        } else {
            $sql = "INSERT INTO clientes (nome, email, telefone, nascimento) VALUES (?, ?, ?, ?)";
            $stmt = $mysqli->prepare($sql);
            if (!$stmt) {
                $erro = "Erro ao preparar SQL: " . $mysqli->error;
            } else {
                $stmt->bind_param("ssss", $nome, $email, $telefone, $nascimento);
                if ($stmt->execute()) {
                    $sucesso = "Cliente cadastrado com sucesso!";
                    // limpar variaveis
                    $nome = $email = $telefone = $nascimento = "";
                } else {
                    $erro = "Erro ao inserir: " . $stmt->error;
                }
                $stmt->close();
            }
        }
    }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cadastro de Clientes</title>
  <style>
    
    body {
      
      background: #e9f0f7;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
    }

    .container {
      background-color: #fff;
      border-radius: 12px;
      box-shadow: 0 6px 18px rgba(0,0,0,0.1);
      width: 100%;
      max-width: 420px;
      padding: 30px 35px;
      box-sizing: border-box;
      text-align: center;
    }

    h2 {
      margin-bottom: 20px;
      color: #2b3a67;
      font-weight: 600;
    }

    a {
      color: #1a73e8;
      font-size: 14px;
      display: inline-block;
      margin-bottom: 15px;
    }

    a:hover {
      text-decoration: underline;
    }

    form {
      display: flex;
      flex-direction: column;
      align-items: stretch;
    }

    label {
      text-align: left;
      font-weight: 600;
      color: #444;
      margin-bottom: 5px;
      display: block;
    }

    input[type="text"],
    input[type="email"] {
      width: 100%;
      padding: 10px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 15px;
      margin-bottom: 15px;
    }

    input[type="text"]:focus,
    input[type="email"]:focus {
      border-color: #1a73e8;
      box-shadow: 0 0 4px rgba(26,115,232,0.4);
    }

    button {
      background-color: #1a73e8;
      color: #fff;
      border: none;
      padding: 12px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 16px;
      font-weight: 600;
    }

    button:hover {
      background-color: #1558b0;
    }

    /* ---------- Rodapé ---------- */
    .footer {
      margin-top: 20px;
      font-size: 13px;
      color: #777;
    }

  </style>
</head>
<body>
  <div class="container">
    <a href="./consultar_clientes.php">← Voltar à lista</a>
    <h2>Cadastro de Cliente</h2>

    <form method="POST" action="">
      <label>Nome:</label>
      <input name="nome" type="text" placeholder="Digite o nome completo" required>

      <label>E-mail:</label>
      <input name="email" type="email" placeholder="exemplo@email.com" required>

      <label>Telefone:</label>
      <input name="telefone" type="text" placeholder="(xx) xxxxx-xxxx" required>

      <label>Data de Nascimento:</label>
      <input name="nascimento" type="text" placeholder="dd/mm/aaaa" required>

      <button type="submit">Salvar Cliente</button>
    </form>

    <div class="footer">
      Sistema para Testes - PHP
    </div>
  </div>
</body>
</html>
