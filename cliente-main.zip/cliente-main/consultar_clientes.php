<?php
require_once "conexao.php";

// Busca todos os clientes (id + nome)
$sql = "SELECT id, nome FROM clientes ORDER BY nome ASC";
$result = $mysqli->query($sql);
$clientes = $result ? $result->fetch_all(MYSQLI_ASSOC) : [];

// Captura o ID do cliente clicado (GET)
$id = isset($_GET['id']) ? (int) $_GET['id'] : 0;
$cliente = null;

if ($id > 0) {
    $sql = "SELECT * FROM clientes WHERE id = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $res = $stmt->get_result();
    $cliente = $res->fetch_assoc();
    $stmt->close();
}

// Função para formatar data
function data_br($data) {
    $d = DateTime::createFromFormat('Y-m-d', $data);
    return $d ? $d->format('d/m/Y') : '';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Consulta de Clientes</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body {
    background: #e9f0f7;
    margin: 0;
    padding: 0;
    display: flex;
    height: 100vh;
  }

  .lista {
    width: 35%;
    background: #fff;
    border-right: 1px solid #ddd;
    overflow-y: auto;
    padding: 20px;
  }
  
  .detalhes {
    flex: 1;
    background: #f8fafc;
    padding: 30px;
  }

  h2 {
    color: #2b3a67;
    margin-top: 0;
  }

  ul {
    list-style: none;
    padding: 0;
    margin: 0;
  }
  li {
    margin-bottom: 6px;
  }
  a.nome {
    text-decoration: none;
    color: #1a73e8;
    padding: 8px 10px;
    display: block;
    border-radius: 6px;
    transition: 0.2s;
  }
  a.nome:hover, a.nome.selecionado {
    background: #e3f2fd;
  }

  .info {
    background: #fff;
    border-radius: 10px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.1);
    padding: 20px;
    max-width: 500px;
  }
  .info p {
    margin: 6px 0;
    font-size: 15px;
  }
  .info strong {
    color: #2b3a67;
  }

  .footer {
    margin-top: 20px;
    font-size: 13px;
    color: #777;
  }

</style>
</head>
<body>
  <!-- Lista de clientes -->
  <div class="lista">
    <h2>Clientes</h2>
    <ul>
      <?php if (empty($clientes)): ?>
        <li>Nenhum cliente cadastrado.</li>
      <?php else: ?>
        <?php foreach ($clientes as $c): ?>
          <li>
            <a class="nome <?= $c['id'] == $id ? 'selecionado' : '' ?>"
               href="?id=<?= $c['id'] ?>">
               <?= htmlspecialchars($c['nome']) ?>
            </a>
          </li>
        <?php endforeach; ?>
      <?php endif; ?>
    </ul>

    <div class="footer">
      <a href="cadastro_cliente.php">+ Cadastrar novo cliente</a>
    </div>
  </div>

  <!-- Detalhes do cliente -->
  <div class="detalhes">
    <?php if ($cliente): ?>
      <div class="info">
        <h2>Detalhes de <?= htmlspecialchars($cliente['nome']) ?></h2>
        <p><strong>ID:</strong> <?= $cliente['id'] ?></p>
        <p><strong>E-mail:</strong> <?= htmlspecialchars($cliente['email']) ?></p>
        <p><strong>Telefone:</strong> <?= htmlspecialchars($cliente['telefone']) ?></p>
        <p><strong>Nascimento:</strong> <?= data_br($cliente['nascimento']) ?></p>
        <p><strong>Cadastro:</strong> <?= htmlspecialchars($cliente['created_at']) ?></p>
      </div>
    <?php else: ?>
      <div class="info">
        <h2>Selecione um cliente na lista</h2>
        <p>Os detalhes aparecerão aqui ao clicar em um nome à esquerda.</p>
      </div>
    <?php endif; ?>
  </div>
</body>
</html>
