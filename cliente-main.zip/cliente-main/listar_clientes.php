<?php
require_once "conexao.php";






// Consulta todos os registros
$sql = "SELECT * FROM clientes ORDER BY id DESC";
$result = $mysqli->query($sql);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<title>Lista de Clientes</title>
<style>
    
    table { width: 100%; border-collapse: collapse; }
    th, td { border: 1px solid #ccc; padding: 8px; text-align: left; }
    th { background-color: #f2f2f2; }
    h2 { text-align: center; }
    .link-voltar { margin-top: 15px; display: inline-block; }
</style>
</head>
<body>

<h2>Lista de Clientes Cadastrados</h2>

<?php if ($result && $result->num_rows > 0): ?>
    <table>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>E-mail</th>
            <th>Telefone</th>
            <th>Data de Nascimento</th>
            <th>Data de Cadastro</th>
        </tr>

        <?php while($cliente = $result->fetch_assoc()): ?>
        <tr>
            <td><?= $cliente['id'] ?></td>
            <td><?= htmlspecialchars($cliente['nome']) ?></td>
            <td><?= htmlspecialchars($cliente['email']) ?></td>
            <td><?= htmlspecialchars($cliente['telefone']) ?></td>
            <td>
                <?php
                    // converte a data do formato MySQL (YYYY-MM-DD) para DD/MM/YYYY
                    $nasc = DateTime::createFromFormat('Y-m-d', $cliente['nascimento']);
                    echo $nasc ? $nasc->format('d/m/Y') : '';
                ?>
            </td>
            <td><?= $cliente['created_at'] ?></td>
        </tr>
        <?php endwhile; ?>
    </table>
<?php else: ?>
    <p>Nenhum cliente cadastrado ainda.</p>
<?php endif; ?>

<a class="link-voltar" href="cadastro_cliente.php">← Voltar ao cadastro</a>

</body>
</html>
